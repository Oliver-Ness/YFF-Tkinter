import tkinter as tk
from tkinter import messagebox
import imaplib
from email import message_from_bytes
import quopri
import json

Kinter = tk.Tk()
Kinter.title("Email Viewer")
Maxwidth = Kinter.winfo_screenwidth()
MaxHeight = Kinter.winfo_screenheight()
Kinter.minsize(1280, 720)
Kinter.configure(bg="White")
isloggedin = False
email_listbox = None
email_variables = []

def decode_quoted_printable(encoded_text):
    return quopri.decodestring(encoded_text).decode('utf-8')

def display_emails():
    global email_listbox, email_variables

    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(AddressCheck, PassCheck)
        mail.select("inbox")
        result, data = mail.search(None, "ALL")

        if result == "OK":
            email_ids = data[0].split()
            all_emails_data = []

            for email_id in email_ids:
                result, message_data = mail.fetch(email_id, "(RFC822)")

                if result == "OK":
                    email_message = message_from_bytes(message_data[0][1])

                    sender = email_message.get("From", "Unknown Sender")
                    subject = email_message.get("Subject", "No Subject")
                    date = email_message.get("Date", "Unknown Date")

                    email_data = f"ID: {len(all_emails_data) + 1}\nSender: {sender}\nSubject: {subject}\nDate: {date}"
                    all_emails_data.append(email_data)

            
            email_variables = all_emails_data

           
            email_listbox.delete(0, tk.END)

            
            for email_data in all_emails_data:
                email_listbox.insert(tk.END, email_data)

        mail.logout()

    except Exception as e:
        print(f"Error: {e}")
        isloggedin = False

def display_email_info():
    selected_index = email_listbox.curselection()
    if selected_index:
        email_id = selected_index[0] + 1  
        email_info = email_variables[email_id - 1]
        messagebox.showinfo("Email Information", email_info)

if not isloggedin:
    def Check():
        global PassCheck, AddressCheck
        global isloggedin, email_listbox  

        PassCheck = Password.get()
        AddressCheck = MailAddress.get()

        try:
            mail = imaplib.IMAP4_SSL("imap.gmail.com")
            mail.login(AddressCheck, PassCheck)
            mail.logout()
            isloggedin = True
        except Exception as e:
            print(f"Login failed: {e}")
            isloggedin = False

        if isloggedin:
            print("Ok")
            Kinter.configure(bg="Blue")

            fetch_button = tk.Button(Kinter, text="Fetch Emails", command=display_emails)
            fetch_button.pack()

            Password.destroy()
            Confirm.destroy()
            MailAddress.destroy()
            MailLabel.destroy()
            PasswordLabel.destroy()
            Error.destroy()

            
            global email_listbox
           
            email_listbox = tk.Listbox(Kinter, selectmode=tk.SINGLE, height=20, width=100)
            email_listbox.pack(fill=tk.BOTH, expand=True)

            scrollbar = tk.Scrollbar(email_listbox, orient=tk.VERTICAL, command=email_listbox.yview)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            email_listbox.config(yscrollcommand=scrollbar.set)
            email_listbox.bind("<Double-Button-1>", lambda event: display_email_info())

        else:
            Error.config(text="ERROR: WRONG ADDRESS OR PASSWORD", foreground="Red", background="White")
            Error.grid(row=4, column=0, columnspan=2)

Kinter.maxsize(Maxwidth, MaxHeight)

login_frame = tk.Frame(Kinter, bg="White")
login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

Login_Text = tk.Label(login_frame, text="LOG IN")
MailLabel = tk.Label(login_frame, text="Email Address")
MailAddress = tk.Entry(login_frame)
PasswordLabel = tk.Label(login_frame, text="Password")
Password = tk.Entry(login_frame, show="*")
Confirm = tk.Button(login_frame, text="Log in", background="Red", command=Check)
Error = tk.Label(login_frame)

Login_Text.grid(row=0, column=1, pady=5)
MailLabel.grid(row=1, column=0, pady=5, sticky=tk.E)
MailAddress.grid(row=1, column=1, pady=5, padx=5)
PasswordLabel.grid(row=2, column=0, pady=5, sticky=tk.E)
Password.grid(row=2, column=1, pady=5, padx=5)
Confirm.grid(row=3, column=0, columnspan=2, pady=10)
Error.grid(row=4, column=0, columnspan=2)

Kinter.mainloop()
